package com.demo.porequest;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class PorequestRegistrationServlet
 */
@WebServlet("/PorequestRegistrationServlet")
public class PorequestRegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PorequestRegistrationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	/*
	 * protected void doGet(HttpServletRequest request, HttpServletResponse
	 * response) throws ServletException, IOException { // TODO Auto-generated
	 * method stub
	 * response.getWriter().append("Served at: ").append(request.getContextPath());
	 * }
	 */
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		PrintWriter out = response.getWriter();
//		out.print("Working");
		String business_unit = request.getParameter("business_unit");
		String business_unit_id = request.getParameter("business_unit_id");
		String warehouse = request.getParameter("warehouse");
		String site = request.getParameter("site");
		String sku_name = request.getParameter("sku_name");
		String sku_id = request.getParameter("sku_id");
		String req_quantity = request.getParameter("quantity");
		String price = request.getParameter("price");
		String address = request.getParameter("address");
		String vendor_site_id = request.getParameter("vendor_site_id");
		String c_name = request.getParameter("c-name");
		String e_date = request.getParameter("edate");
		String status = request.getParameter("status");
//		String site = request.getParameter("site");
//		String sku_name = request.getParameter("sku_name");
		RequestDispatcher dispatcher = null;
		Connection con = null;
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		ResultSet resultSetn = null;
		String skuname = null;
		String skugroup = null;
		String skuprice = null;
		String busname = null;
		try {
			System.out.print("hai");
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project?useSSL=false", "root",
					"Hari_viswesh@1999");
			statement=con.createStatement();
			PreparedStatement pst = con.prepareStatement(
					"INSERT INTO `project`.`po_request`(`business_unit`,`business_unit_id`,`warehouse`,`site`,`sku_name`,`sku_id`,`quantity`,`price`,`address`,`vendor_site_id`,`c_name`,`e_date`,`status`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");
			pst.setString(1, business_unit);
			pst.setString(2, business_unit_id);
			pst.setString(3, warehouse);
			pst.setString(4, site);
			pst.setString(5, sku_name);
			pst.setString(6, sku_id);
			pst.setString(7, req_quantity);
			pst.setString(8, price);
			pst.setString(9, address);
			pst.setString(10, vendor_site_id);
			pst.setString(11, c_name);
			pst.setString(12, e_date);
			pst.setString(13, status);
			
			int rowCount = pst.executeUpdate();
			dispatcher = request.getRequestDispatcher("Po_creation.jsp");
			if (rowCount > 0) {
				request.setAttribute("status", "success");
			} else {
				request.setAttribute("status", "failed");

			}
			dispatcher.forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
