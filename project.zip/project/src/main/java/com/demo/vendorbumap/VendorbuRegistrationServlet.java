package com.demo.vendorbumap;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection; 
/**
 * Servlet implementation class VendorbuRegistrationServlet
 */
@WebServlet("/VendorbuRegistrationServlet")
public class VendorbuRegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public VendorbuRegistrationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
//	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
//	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
//		PrintWriter out = response.getWriter();
//		out.print("Working");
		
//		String registerForm = "./pages/form-validation.jsp";
//		RequestDispatcher dispatcher = request.getRequestDispatcher(registerForm);
//		dispatcher.forward(request, response);

//		String Vendorid=request.getParameter("Vendorid");

		String vendor_id = request.getParameter("vendor_id");
		String business_unit = request.getParameter("business_unit");
		String warehouse = request.getParameter("warehouse");
		String site = request.getParameter("site");
		String c_name = request.getParameter("c_name");
		String p_method = request.getParameter("p_method");
		String term_code = request.getParameter("term_code");
		String schedule_month = request.getParameter("schedule_month");
		String edi_location = request.getParameter("edi_location");
		String site_addredd = request.getParameter("site_addredd");
		String federal_id = request.getParameter("federal_id");
		String fein_id = request.getParameter("fein_id");
		String fis_vendor_site = request.getParameter("fis_vendor_site");
		String vendor_account_no = request.getParameter("vendor_account_no");
		
		
		RequestDispatcher dispatcher = null;
		Connection con = null;
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		
		String wareid;
		String busname = null;
		try {
			System.out.print("hai");
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project?useSSL=false", "root",
					"Hari_viswesh@1999");
			statement=con.createStatement();
			String sql = "select * from `project`.`business_unit` where business_unit_id=?";
			PreparedStatement pstr = con.prepareStatement(sql);
			pstr.setString(1, business_unit);
			resultSet = pstr.executeQuery();
			while (resultSet.next()) {

				busname=resultSet.getString("business_unit_name");
				// System.out.println(rs.getString(1));
			}
			
			PreparedStatement pst = con.prepareStatement(
					"INSERT INTO `project`.`vendor_site_bu_map`(`vendor_id`,`business_unit`,`warehouse`,`site`,`c-name`,`p-method`,`term_code`,`schedule_month`,`edi_location`,`site_addredd`,`federal_id`,`fein_id`,`fis_vendor_site`,`vendor_account_no`,`business_unit_id`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			pst.setString(1, vendor_id);
			pst.setString(2, busname);
			pst.setString(3, warehouse);
			pst.setString(4, site);
			pst.setString(5, c_name);
			pst.setString(6, p_method);
			pst.setString(7, term_code);
			pst.setString(8, schedule_month);
			pst.setString(9, edi_location);
			pst.setString(10, site_addredd);
			pst.setString(11, federal_id);
			pst.setString(12, fein_id);
			pst.setString(13, fis_vendor_site);
			pst.setString(14, vendor_account_no);
			pst.setString(15, business_unit);
			int rowCount = pst.executeUpdate();
			dispatcher = request.getRequestDispatcher("VendorsiteBUmap.jsp");
			if (rowCount > 0) {
				request.setAttribute("status", "success");
			} else {
				request.setAttribute("status", "failed");

			}
			dispatcher.forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		


	}

}
