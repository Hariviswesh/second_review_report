package com.demo.vendorbuskumap;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;

/**
 * Servlet implementation class VendorbuskuRegistrationServlet
 */
@WebServlet("/VendorbuskuRegistrationServlet")
public class VendorbuskuRegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public VendorbuskuRegistrationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	/*
	 * protected void doGet(HttpServletRequest request, HttpServletResponse
	 * response) throws ServletException, IOException { // TODO Auto-generated
	 * method stub
	 * response.getWriter().append("Served at: ").append(request.getContextPath());
	 * }
	 */

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		PrintWriter out = response.getWriter();
//		out.print("Working");
		String business_unit = request.getParameter("business_unit");
		String warehouse = request.getParameter("warehouse");
		String vendor_id = request.getParameter("vendor_id");
		String sku_group_type = request.getParameter("sku_group_type");
		String sku_id = request.getParameter("sku_name");
		String vendor_site_id = request.getParameter("vendor_site_id");
		String c_name = request.getParameter("c-name");
		String site = request.getParameter("site");
//		String sku_name = request.getParameter("sku_name");
		RequestDispatcher dispatcher = null;
		Connection con = null;
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		ResultSet resultSetn = null;
		String skuname = null;
		String skugroup = null;
		String skuprice = null;
		String busname = null;
		try {
			System.out.print("hai");
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project?useSSL=false", "root",
					"Hari_viswesh@1999");
			statement=con.createStatement();
			String sql = "select * from `project`.`sku_profile` where sku_id=?";
			String sqlb = "select * from `project`.`business_unit` where business_unit_id=?";
			PreparedStatement pstr = con.prepareStatement(sql);
			PreparedStatement pstrs = con.prepareStatement(sqlb);
			pstr.setString(1, sku_id);
			pstrs.setString(1, business_unit);
			resultSet = pstr.executeQuery();
			resultSetn = pstrs.executeQuery();
			while (resultSet.next()) {

				skuname=resultSet.getString("sku_name");
				skugroup=resultSet.getString("sku_group");
				skuprice=resultSet.getString("sku_price");
				// System.out.println(rs.getString(1));
			}
			while (resultSet.next()) {

				busname=resultSet.getString("business_unit_name");
				// System.out.println(rs.getString(1));
			}
			PreparedStatement pst = con.prepareStatement(
					"INSERT INTO `project`.`vendor_site_bu_sku_mapping`(`sku_id`,`business_unit`,`warehouse`,`vendor_id`,`sku_group_type`,`vendor_site_id`,`c-name`,`site`,`sku_name`,`sku_group`,`sku_price`) VALUES (?,?,?,?,?,?,?,?,?,?)");
			pst.setString(1, sku_id);
			pst.setString(2, busname);
			pst.setString(3, warehouse);
			pst.setString(4, vendor_id);
			pst.setString(5, sku_group_type);
			pst.setString(6, vendor_site_id);
			pst.setString(7, c_name);
			pst.setString(8, site);
			pst.setString(9, skuname);
			pst.setString(10, skugroup);
			pst.setString(11, skuprice);
			pst.setString(12, business_unit);
			
			int rowCount = pst.executeUpdate();
			dispatcher = request.getRequestDispatcher("VendorBUSKUmap.jsp");
			if (rowCount > 0) {
				request.setAttribute("status", "success");
			} else {
				request.setAttribute("status", "failed");

			}
			dispatcher.forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
